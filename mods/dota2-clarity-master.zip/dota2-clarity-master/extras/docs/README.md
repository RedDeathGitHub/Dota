This folder contains various documentation on console commands.
