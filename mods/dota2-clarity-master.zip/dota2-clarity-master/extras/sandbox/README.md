This folder contains code written to generate console commands for various
purposes. This is kept here for reference and development. You can safely
ignore this folder, but if you're curious how certain things are generated
(tower range circles, camp spawn boxes) you can look at the code.
