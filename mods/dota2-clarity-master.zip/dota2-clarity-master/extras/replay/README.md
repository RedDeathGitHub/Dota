Running this .reg will allow you to enter replay URLs into the Windows
run dialog (windows key + R) to have Dota 2 download the replay file.
A replay url is for example "dota2://matchid=459788526".
