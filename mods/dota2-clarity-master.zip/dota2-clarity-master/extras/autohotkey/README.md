These are my Autohotkey settings for Dota 2. The main enhancement is to swap
CTRL and ALT because for some reason Dota 2 doesn't allow you to do so. This
script just contains key bindings; there are no game-breaking keyboard or mouse
macros inside.
